package med.voll.api.domain.consulta;

public enum MotivoCancelamiento {

        PACIENTE_DESISTIO,
        MEDICO_CANCELO,
        OTROS;

}
