package med.voll.api.domain.consulta.dto;

public record DatosRelatoriosConsultaMensual(String nome, String crm, Long quantidadeConsultasNoMes) {
}


