let playerPaddle, computerPaddle, ball, backgroundImg;
let playerScore = 0, computerScore = 0;
const PADDING = 10; // Espacio para el marco

// Variables para almacenar las imágenes
let paddleImg, ballImg;

function preload() {
    // Cargar los sprites
    paddleImg = loadImage('sprites/barra2.png');
    ballImg = loadImage('sprites/bola.png');
    backgroundImg = loadImage('sprites/fondo2.png');
}

function setup() {
    createCanvas(800, 400);

    // Inicializar paletas y bola
    playerPaddle = new Paddle(true);
    computerPaddle = new Paddle(false);
    ball = new Ball();
}

function draw() {
    // Mostrar el fondo del juego
    background(backgroundImg);

    // Mostrar puntaje
    displayScores();

    // Mostrar y mover las paletas y la bola
    playerPaddle.show();
    playerPaddle.move();

    computerPaddle.show();
    computerPaddle.aiMove(ball);

    ball.show();
    ball.move();

    // Detectar colisiones con las paletas
    ball.checkPaddleCollision(playerPaddle);
    ball.checkPaddleCollision(computerPaddle);

    // Verificar si alguien ha anotado
    ball.checkScore();
}

class Paddle {
    constructor(isPlayer) {
        this.width = 20;
        this.height = 100;
        this.x = isPlayer ? PADDING + 10 : width - PADDING - 30;
        this.y = height / 2 - this.height / 2;
        this.isPlayer = isPlayer;
    }

    show() {
        // Mostrar la imagen de la paleta
        image(paddleImg, this.x, this.y, this.width, this.height);
    }

    move() {
        if (this.isPlayer) {
            this.y = constrain(mouseY - this.height / 2, PADDING, height - PADDING - this.height);
        }
    }

    aiMove(ball) {
        if (!this.isPlayer) {
            if (ball.y < this.y + this.height / 2) {
                this.y -= 5;
            } else if (ball.y > this.y + this.height / 2) {
                this.y += 5;
            }
            this.y = constrain(this.y, PADDING, height - PADDING - this.height);
        }
    }
}

class Ball {
    constructor() {
        this.size = 20;
        this.reset();
    }

    reset() {
        this.x = width / 2;
        this.y = height / 2;
        this.speed = 5;
        this.angle = random([-1, 1]) * random(PI / 4); // Ángulo entre -45 y 45 grados en radianes
        this.xSpeed = this.speed * cos(this.angle);
        this.ySpeed = this.speed * sin(this.angle);
    }

    show() {
        // Mostrar la imagen de la bola
        image(ballImg, this.x - this.size / 2, this.y - this.size / 2, this.size, this.size);
    }

    move() {
        this.x += this.xSpeed;
        this.y += this.ySpeed;

        if (this.y <= PADDING || this.y >= height - PADDING) {
            this.ySpeed *= -1;
        }
    }

    checkPaddleCollision(paddle) {
        if (this.x - this.size / 2 < paddle.x + paddle.width &&
            this.x + this.size / 2 > paddle.x &&
            this.y - this.size / 2 < paddle.y + paddle.height &&
            this.y + this.size / 2 > paddle.y) {

            // Invertir la dirección en x
            this.xSpeed *= -1;

            // Generar un ángulo de rebote entre -45 y 45 grados
            this.angle = map(this.y - (paddle.y + paddle.height / 2), -paddle.height / 2, paddle.height / 2, -PI / 4, PI / 4);

            // Ajustar las velocidades en x e y según el nuevo ángulo
            this.xSpeed = this.speed * cos(this.angle) * (paddle.isPlayer ? 1 : -1);
            this.ySpeed = this.speed * sin(this.angle);

            // Ajustar la posición de la pelota para evitar quedar atrapada en la paleta
            this.x = paddle.isPlayer ? paddle.x + paddle.width + this.size / 2 : paddle.x - this.size / 2;
        }
    }

    checkScore() {
        if (this.x < PADDING) {
            computerScore++;
            this.reset();
        } else if (this.x > width - PADDING) {
            playerScore++;
            this.reset();
        }
    }
}

function displayScores() {
    textAlign(CENTER);
    textSize(32);
    fill(255);
    text(playerScore, width / 4, 50);
    text(computerScore, 3 * width / 4, 50);
}

function drawBorder() {
    noFill();
    stroke(255);
    strokeWeight(4);
    rect(PADDING, PADDING, width - PADDING * 2, height - PADDING * 2);
}
